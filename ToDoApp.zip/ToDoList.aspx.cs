using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace ToDo
{
	/// <summary>
	/// This web form shows a list of all to do items
	/// </summary>
	public class ToDoListForm : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid ToDoDataGrid;

		protected string _title;
		protected string[] _priorityUrls = { "down.png", "nothing.png", "up.png" };
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			int query = 2;

			if (IsPostBack)
			{
				query = (int)ViewState["query"];
			}
			else
			{
				string queryStr = Request.Params["query"];

				if (queryStr != null)
					query = Int32.Parse(queryStr);
			
				// Save state for use in post back	
				ViewState["query"] = query;
			}
			
			string connStr = ConfigurationSettings.AppSettings["ConnectionString"];
			string sql;
			string qryTitle;

			ButtonColumn bcDone;
			ButtonColumn bcEdit;
			ButtonColumn bcDelete;
			ButtonColumn bcReopen;
			BoundColumn bcOpened;
			BoundColumn bcClosed;
			
			switch (query)
			{
				case 0:
					qryTitle = "All Items";
					sql = "select * from items order by priority desc";

					bcOpened = new BoundColumn();
					bcOpened.HeaderText = "Opened";
					bcOpened.DataField = "Opened";
					ToDoDataGrid.Columns.Add(bcOpened);
					break;

				case 1:
					qryTitle = "All Closed Items";
					sql = "SELECT * FROM Items WHERE Closed Is Not Null order by priority desc";

					bcClosed = new BoundColumn();
					bcClosed.HeaderText = "Closed";
					bcClosed.DataField = "Closed";
					ToDoDataGrid.Columns.Add(bcClosed);

					bcReopen = new ButtonColumn();
					bcReopen.Text = "Reopen";
					bcReopen.CommandName = "ReopenToDo";
					ToDoDataGrid.Columns.Add(bcReopen);

					bcDelete = new ButtonColumn();
					bcDelete.Text = "Delete";
					bcDelete.CommandName = "DeleteToDo";
					ToDoDataGrid.Columns.Add(bcDelete);
					break;

				default:
				case 2:
					qryTitle = "All Open Items";
					sql = "SELECT * FROM Items WHERE Closed Is Null order by priority desc";

					bcDone = new ButtonColumn();
					bcDone.Text = "Done";
					bcDone.CommandName = "DoneToDo";
					ToDoDataGrid.Columns.Add(bcDone);

					bcEdit = new ButtonColumn();
					bcEdit.Text = "Edit";
					bcEdit.CommandName = "EditToDo";
					ToDoDataGrid.Columns.Add(bcEdit);

					bcDelete = new ButtonColumn();
					bcDelete.Text = "Delete";
					bcDelete.CommandName = "DeleteToDo";
					ToDoDataGrid.Columns.Add(bcDelete);
					break;
			}

			_title = "To Do List - " + qryTitle;

			OleDbDataAdapter adapter = new OleDbDataAdapter(sql, connStr);
			
			DataSet ds = new DataSet();

			adapter.Fill(ds);
			ToDoDataGrid.DataSource = ds;
			ToDoDataGrid.DataBind();
		}

		public void ToDoDataGrid_Command(Object sender, DataGridCommandEventArgs e) 
		{
			TableCell idCell = e.Item.Cells[0];
			string idStr = idCell.Text;
			string cmdStr = ((LinkButton)e.CommandSource).CommandName;
          
			if (cmdStr == "EditToDo") 
			{
				Response.Redirect("EditItem.aspx?id=" + idStr);
			}

			string connStr = ConfigurationSettings.AppSettings["ConnectionString"];
			string sql;

			switch (cmdStr)
			{
				case "DeleteToDo":
					sql = "DELETE FROM Items WHERE ID=" + idStr;
					break;
					
				case "ReopenToDo":
					sql = "UPDATE Items SET Closed = Null WHERE ID=" + idStr;
					break;
				
				default:
					sql = "UPDATE Items SET Closed = NOW() WHERE ID=" + idStr;
					break;
			}
		
			OleDbConnection conn = new OleDbConnection(connStr);
					
			try
			{
				conn.Open();
			
				OleDbCommand cmd = new OleDbCommand(sql, conn);
			
				cmd.ExecuteNonQuery();		
			}
			finally
			{				
				conn.Close();
			}
			
			// Cause the page to be refreshed
			Response.Redirect(Request.FilePath + "?query=" + ViewState["query"].ToString());
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
