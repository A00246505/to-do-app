using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace ToDo
{
	/// <summary>
	/// Summary description for EditItem.
	/// </summary>
	public class EditItemForm : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.LinkButton SaveButton;
		protected System.Web.UI.WebControls.TextBox DescriptionTextBox;
		protected System.Web.UI.WebControls.Label ErrorLabel;
		protected System.Web.UI.WebControls.DropDownList PriorityList;
		
		protected string _title;
		protected System.Web.UI.WebControls.LinkButton Save;
		protected static string[] _priorities = {"Low", "Medium", "High"};

		private void Page_Load(object sender, System.EventArgs e)
		{
			string idStr = Request.Params["id"];
				
			_title = (idStr == null ? "New" : "Edit") + " To Do List Item";
				
			if (!IsPostBack)
			{
				foreach (string s in _priorities)
					PriorityList.Items.Add(s);
					
				if (idStr != null)
				{
					string connStr = ConfigurationSettings.AppSettings["ConnectionString"];
					string queryStr = "select * from Items where id=" + idStr;
					OleDbDataAdapter adapter = new OleDbDataAdapter(queryStr, connStr);
					
					DataSet ds = new DataSet();
					
					adapter.Fill(ds);
					
					DataTable tbl = ds.Tables[0];
					
					if (tbl.Rows.Count > 0)
					{
						DataRow row = tbl.Rows[0];
					
						DescriptionTextBox.Text = row["Description"].ToString();
						PriorityList.SelectedIndex = (int)row["Priority"] - 1;
					}
				}
				
			}
			else
			{
				OnSubmit();
			}
		}
		
		public void SaveButton_Click(object sender, System.EventArgs e)
		{
			OnSubmit();
		}

		protected void OnSubmit()
		{
			string connStr = ConfigurationSettings.AppSettings["ConnectionString"];
			string sql;
			string idStr = Request.Params["id"];
			string desc = DescriptionTextBox.Text.Replace("'", "''");
			int priority = PriorityList.SelectedIndex + 1;
				
			if (idStr == null)
				sql = "INSERT INTO Items (Description, Priority) VALUES ('" + desc + "', " + priority + ")";
			else
				sql = "UPDATE Items SET Description = '" + desc + "', Priority=" + 
					priority + " WHERE ID=" + idStr;
				
			OleDbConnection conn = new OleDbConnection(connStr);
							
			try
			{
				conn.Open();
						
				OleDbCommand cmd = new OleDbCommand(sql, conn);
						
				cmd.ExecuteNonQuery();		
			}
			catch (OleDbException e)
			{
				ErrorLabel.Text = e.Message;
				ErrorLabel.Visible = true;
				return;
			}
			finally
			{				
				conn.Close();
			}
					
			Response.Redirect("ToDoList.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ID = "EditItemForm";
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
